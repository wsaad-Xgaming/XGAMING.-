const express = require('express');
const cors = require('cors');
const multer = require('multer');
const fs = require('fs');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 10000;
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';
const DATA_FILE = path.join(__dirname, 'games.json');
const UPLOAD_DIR = path.join(__dirname, 'uploads');

fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DATA_FILE)) fs.writeFileSync(DATA_FILE, '[]', 'utf8');

app.use(cors());
app.use(express.json({ limit: '2mb' }));
app.use('/uploads', express.static(UPLOAD_DIR));

function readGames() {
  try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
  catch { return []; }
}
function writeGames(games) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(games, null, 2), 'utf8');
}
function auth(req, res, next) {
  if (!ADMIN_TOKEN) return res.status(503).json({ error: 'ADMIN_TOKEN_NOT_CONFIGURED' });
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  if (token !== ADMIN_TOKEN) return res.status(401).json({ error: 'UNAUTHORIZED' });
  next();
}

app.get('/', (_req, res) => res.json({ name: 'X Gaming Server', status: 'online' }));
app.get('/api/health', (_req, res) => res.json({ ok: true, status: 'online', time: new Date().toISOString() }));
app.get('/api/games', (_req, res) => res.json(readGames()));
app.get('/api/images', (_req, res) => res.json([]));

app.post('/api/games', auth, (req, res) => {
  const body = req.body || {};
  if (!body.name) return res.status(400).json({ error: 'NAME_REQUIRED' });
  const games = readGames();
  const game = {
    id: Number(body.id) || Date.now(),
    name: String(body.name),
    cat: String(body.cat || 'كل الألعاب'),
    image: body.image || '',
    apk: body.apk || '',
    obb: body.obb || '',
    data: body.data || '',
    size: body.size || ''
  };
  const index = games.findIndex(g => g.id === game.id);
  if (index >= 0) games[index] = game; else games.unshift(game);
  writeGames(games);
  res.json(game);
});

app.delete('/api/games/:id', auth, (req, res) => {
  const id = Number(req.params.id);
  const games = readGames();
  const next = games.filter(g => Number(g.id) !== id);
  if (next.length === games.length) return res.status(404).json({ error: 'NOT_FOUND' });
  writeGames(next);
  res.json({ ok: true });
});

const upload = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: 10 * 1024 * 1024 }
});
app.post('/api/images', auth, upload.single('image'), (req, res) => {
  if (!req.file) return res.status(400).json({ error: 'IMAGE_REQUIRED' });
  const ext = path.extname(req.file.originalname) || '.bin';
  const finalName = `${Date.now()}_${req.file.filename}${ext}`;
  const finalPath = path.join(UPLOAD_DIR, finalName);
  fs.renameSync(req.file.path, finalPath);
  res.json({ id: finalName, url: `/uploads/${finalName}` });
});

app.delete('/api/images/:id', auth, (req, res) => {
  const file = path.basename(req.params.id);
  const target = path.join(UPLOAD_DIR, file);
  if (fs.existsSync(target)) fs.unlinkSync(target);
  res.json({ ok: true });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`X Gaming Server listening on port ${PORT}`);
});
